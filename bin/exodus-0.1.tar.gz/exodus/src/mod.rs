extern crate postgres;
extern crate openssl;
extern crate hyper;

use nickel::{Router, HttpRouter, MediaType, JsonBody};
use nickel::status::StatusCode;
use postgres::{Connection};
use std::sync::{Arc, Mutex};
use std::vec::Vec;

extern crate rustc_serialize;
use rustc_serialize::{json};

#[derive(RustcDecodable, RustcEncodable)]
struct Hoge {
    _id: Option<i32>,
    
}

pub fn url(shared_connection: Arc<Mutex<Connection>>, router: &mut Router) {
    let conn = shared_connection.clone();
    router.get("/setup/hoge", middleware! { |_, response|

    return match conn.lock().unwrap().execute("CREATE TABLE hoge (id SERIAL PRIMARY KEY, )",
    &[]) {
            Ok(_) => return response.send("Hoge table was created."),
            Err(err) => return response.send(format!("Error running query: {:?}", err))
        };
    });

    router.get("/", middleware! { |_, mut response|
        response.set(MediaType::Html);
        return response.send_file("app/hoge/views/index.tpl")
    });

    // select all
    let conn = shared_connection.clone();
    router.get("/api/hoges", middleware! { |_, mut response|
        let conn = conn.lock().unwrap();
        let hoges = conn.query("SELECT  FROM hoge WHERE ", &[]).unwrap();
        let mut v: Vec<Hoge> = vec![];

        for row in &hoges {
            let hoge = Hoge {
                _id: row.get(0), 
            };

            v.push(hoge);
        }

        let json_obj = json::encode(&v).unwrap();
        response.set(MediaType::Json);
        response.set(StatusCode::Ok);
        return response.send(json_obj);
    });

    // insert
    let conn = shared_connection.clone();
    router.post("/api/hoges", middleware! { |request, mut response|
        let conn = conn.lock().unwrap();
        let stmt = match conn.prepare("INSERT INTO hoge () VALUES ()") {
            Ok(stmt) => stmt,
            Err(e) => {
                return response.send(format!("Preparing query failed: {}", e));
            }
        };

        let hoge = request.json_as::<Hoge>().unwrap();
        match stmt.execute(&[
            &hoge.title.to_string(),
            &hoge.releaseYear,
            &hoge.director.to_string(),
            &hoge.genre.to_string()
        ]) {
            Ok(_) => {
                println!("Inserting hoge was Success.");
                response.set(StatusCode::Ok);
            },
            Err(e) => println!("Inserting hoge failed. => {:?}", e),
        };

        return response.send("");
    });

    // select one
    let conn = shared_connection.clone();
    router.get("/api/hoges/:id", middleware! { |request, mut response|
        let conn = conn.lock().unwrap();
        let hoge = conn.query(
            "SELECT  FROM hoge WHERE  WHERE id = $1",
            &[&request.param("id").unwrap().parse::<i32>().unwrap()]
        ).unwrap();

        for row in &hoge {
            let hoge = Hoge {
                _id: row.get(0), 
            };

            let json_obj = json::encode(&hoge).unwrap();
            // MediaType can be any valid type for reference see
            response.set(MediaType::Json);
            response.set(StatusCode::Ok);
            return response.send(json_obj);
        }
    });

    // update
    let conn = shared_connection.clone();
    router.put("/api/hoges/:id", middleware! { |request, mut response|
        let conn = conn.lock().unwrap();
        let stmt = match conn.prepare("UPDATE hoge SET  WHERE id = $1") {
            Ok(stmt) => stmt,
            Err(e) => {
                return response.send(format!("Preparing query failed: {}", e));
            }
        };

        // JSON to object
        let hoge = request.json_as::<Hoge>().unwrap();
        match stmt.execute(&[
            &hoge.title.to_string(),
            &hoge.releaseYear,
            &hoge.director.to_string(),
            &hoge.genre.to_string(),
            &hoge._id
        ]) {
            Ok(_) => {
                println!("Updating hoge was Success.");
                response.set(StatusCode::Ok);
            },
            Err(e) => println!("Updating hoge failed. => {:?}", e),
        };

        return response.send("");
    });

    // delete
    let conn = shared_connection.clone();
    router.delete("/api/hoges/:id", middleware! { |request, mut response|
        let conn = conn.lock().unwrap();
        let stmt = match conn.prepare("DELETE FROM hoge WHERE id = $1") {
            Ok(stmt) => stmt,
            Err(e) => {
                return response.send(format!("Preparing query failed: {}", e));
            }
        };

        match stmt.execute(&[
            &request.param("id").unwrap().parse::<i32>().unwrap()
        ]) {
            Ok(_) => {
                println!("Deleting hoge was Success.");
                response.set(StatusCode::Ok);
            },
            Err(e) => println!("Deleting hoge failed. => {:?}", e),
        };

        return response.send("");
    });
}
